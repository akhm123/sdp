from django.apps import AppConfig


class AdminhomeConfig(AppConfig):
    name = 'adminhome'
